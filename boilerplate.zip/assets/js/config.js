var config = {
    env: 'dev',
    siteUrl: window.location.host + window.location.pathname,
    analytics: {
        ga: {
            id: '',
            enable: true
        }
    },
    plugins:{
        isOwlCarousel:false,
        isFullpageJS:false,
    }
}